/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import java.util.List;
import model.Model_Barang;

/**
 *
 * @author Apis
 */
public interface Service_Barang {
    void tambahData (Model_Barang mobar);
    void perbaruiData (Model_Barang mobar);
    void hapusData (Model_Barang mobar);
    
    Model_Barang getById (String Id);
    
    List<Model_Barang> ambilData();
    List<Model_Barang> ambilData2();
    
    List<Model_Barang> pencarian (String Id);
    List<Model_Barang> pencarian2 (String Id);
}
