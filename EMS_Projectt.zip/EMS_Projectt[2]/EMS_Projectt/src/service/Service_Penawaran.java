/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import java.util.List;
import model.Model_Penawaran;

/**
 *
 * @author Apis
 */
public interface Service_Penawaran {
    void tambahData (Model_Penawaran monaw);
    void perbaruiData (Model_Penawaran monaw);
    void hapusData (Model_Penawaran monaw);
    
    Model_Penawaran getById (String Id);
    Model_Penawaran getDataByID (String Id);
     List<Model_Penawaran> getData();
    
    List<Model_Penawaran> ambilData();
    List<Model_Penawaran> ambilData2();
    
    List<Model_Penawaran> pencarian (String Id);
    List<Model_Penawaran> pencarian2 (String Id);
    
    public String nomor();
}
