/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import java.util.List;
import model.Model_Perjalanan;
/**
 *
 * @author Apis
 */
public interface Service_Perjalanan {
    void tambahData (Model_Perjalanan mojal);
    void perbaruiData (Model_Perjalanan mojal);
    void hapusData (Model_Perjalanan mojal);
    
    Model_Perjalanan getById (String id);
    
    List<Model_Perjalanan> getDataByID();
    List<Model_Perjalanan> getData();
    
    List<Model_Perjalanan> pencarian (String id);
    List<Model_Perjalanan> pencarian2 (String id);

    public String nomor();
    
    
}
