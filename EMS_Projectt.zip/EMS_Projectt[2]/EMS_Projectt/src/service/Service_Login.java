/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import model.Model_Login;
/**
 *
 * @author Apis
 */
public interface Service_Login {
    void prosesLogin (Model_Login mod_login);
}
