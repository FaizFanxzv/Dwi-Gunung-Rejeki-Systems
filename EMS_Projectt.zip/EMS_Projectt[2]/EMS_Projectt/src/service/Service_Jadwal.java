/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import java.util.List;
import model.Model_Jadwal;

/**
 *
 * @author Apis
 */
public interface Service_Jadwal {
    void tambahData (Model_Jadwal mojad);
    void perbaruiData (Model_Jadwal mojad);
    void hapusData (Model_Jadwal mojad);
    
    Model_Jadwal getById (String Id);
    Model_Jadwal getDataByID (String Id);
    List<Model_Jadwal> getData();
    
    List<Model_Jadwal> ambilData();
    List<Model_Jadwal> ambilData2();
    
    List<Model_Jadwal> pencarian (String Id);
    List<Model_Jadwal> pencarian2 (String Id);
    
    public String nomor();
}
