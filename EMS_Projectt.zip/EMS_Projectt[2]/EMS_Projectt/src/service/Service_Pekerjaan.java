/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import java.util.List;
import model.Model_Pekerjaan;

/**
 *
 * @author Apis
 */
public interface Service_Pekerjaan {
    void tambahData (Model_Pekerjaan mojaan);
    void perbaruiData (Model_Pekerjaan mojaan);
    void hapusData (Model_Pekerjaan mojaan );
    
    Model_Pekerjaan getDataById (String Id);
    Model_Pekerjaan getById (String Id);
    
     List<Model_Pekerjaan> getData();
    
    List<Model_Pekerjaan> ambilData();
    List<Model_Pekerjaan> ambilData2();
    
    List<Model_Pekerjaan> pencarian (String Id);
    List<Model_Pekerjaan> pencarian2 (String Id);
    
    public String nomor();
}
