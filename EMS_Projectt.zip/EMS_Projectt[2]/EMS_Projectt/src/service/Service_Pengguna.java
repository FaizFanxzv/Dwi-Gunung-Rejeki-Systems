/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import java.util.List;
import javax.swing.JLabel;
import model.Model_User;
/**
 *
 * @author Apis
 */
public interface Service_Pengguna {
    void tambahData     (Model_User mod_pengguna);
    void perbaruiData     (Model_User mod_pengguna);
    void hapusData     (Model_User mod_pengguna);
    
    Model_User getById (String Id);
    List<Model_User> getData();
    List<Model_User> pencarian(String Id);
    
    void tampilGambar(JLabel lb_gambar, String id);
    
}
