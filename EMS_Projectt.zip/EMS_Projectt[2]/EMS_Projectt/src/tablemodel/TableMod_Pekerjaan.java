/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablemodel;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import model.Model_Pekerjaan;

/**
 *
 * @author Apis
 */
public class TableMod_Pekerjaan extends AbstractTableModel {
     private List<Model_Pekerjaan> list = new ArrayList<>();
    
    
    public void tambahData (Model_Pekerjaan mojaan) {
        list.add(mojaan);
        fireTableRowsInserted(list.size() -1, list.size()-1 );
        JOptionPane.showMessageDialog(null, "Data berhasil disimpan");
    }
    
    public void perbaruiData (int row, Model_Pekerjaan mojaan) {
        list.add(row, mojaan);
        fireTableDataChanged();
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui");
    }
    
    public void hapusData (int index, Model_Pekerjaan mojaan) {
        list.remove(index);
        fireTableRowsDeleted(index, index);
        JOptionPane.showMessageDialog(null, "Data berhasil di hapus");
    }
    
    public void clear() {
        list.clear();
        fireTableDataChanged();
    }
    
    public void setData (List<Model_Pekerjaan> list) {
        clear();
        this.list.addAll(list);
        fireTableDataChanged();
    }
    
    public void setData (int index, Model_Pekerjaan mojaan){
        list.set(index, mojaan);
        fireTableRowsUpdated(index, index);
    }
    
    public Model_Pekerjaan getData (int index) {
        return list.get(index);
    }
    
    @Override
    public int getRowCount() {
        return list.size();
    }
    
    private final String[] columnNames = {"No","idNo","Tanggal","Nama Customer","alamat","Hitungan","Job","Poin","Teknisi","Upah","Keterangan"};

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        if (columnIndex == 0 ) {
            return "   " +  (rowIndex + 1);
        } else {
       switch (columnIndex -1 ) {
           case 0: return list.get(rowIndex).getIdno();
           case 1: return list.get(rowIndex).getTanggal();
           case 2: return list.get(rowIndex).getCustomer();
           case 3: return list.get(rowIndex).getAlamat();
           case 4: return list.get(rowIndex).getHitungan();
           case 5: return list.get(rowIndex).getJob();
           case 6: return list.get(rowIndex).getPoin();
           case 7: return list.get(rowIndex).getTeknisi();
           case 8: return list.get(rowIndex).getUpah();
           case 9: return list.get(rowIndex).getKeterangan();
           
           default: return null;
            }
       }
    }
    
    public String getColumnName(int column) {
        if (column == 0) {
            return "   " + columnNames[column];
        } else {
            return columnNames[column];
        }
    }
}
