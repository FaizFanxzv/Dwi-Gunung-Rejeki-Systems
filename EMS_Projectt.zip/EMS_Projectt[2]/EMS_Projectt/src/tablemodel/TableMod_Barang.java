/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablemodel;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import model.Model_Barang;

/**
 *
 * @author Apis
 */
public class TableMod_Barang extends AbstractTableModel {
    
    private List<Model_Barang> list = new ArrayList<>();
    
    
    public void tambahData (Model_Barang mobar) {
        list.add(mobar);
        fireTableRowsInserted(list.size() -1, list.size()-1 );
        JOptionPane.showMessageDialog(null, "Data berhasil disimpan");
    }
    
    public void perbaruiData (int row, Model_Barang mobar) {
        list.add(row, mobar);
        fireTableDataChanged();
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui");
    }
    
    public void hapusData (int index, Model_Barang mobar) {
        list.remove(index);
        fireTableRowsDeleted(index, index);
        JOptionPane.showMessageDialog(null, "Data berhasil di hapus");
    }
    
    public void clear() {
        list.clear();
        fireTableDataChanged();
    }
    
    public void setData (List<Model_Barang> list) {
        clear();
        this.list.addAll(list);
        fireTableDataChanged();
    }
    
    public void setData (int index, Model_Barang mobar){
        list.set(index, mobar);
        fireTableRowsUpdated(index, index);
    }
    
    public Model_Barang getData (int index) {
        return list.get(index);
    }
    
    @Override
    public int getRowCount() {
        return list.size();
    }

    @Override
    public int getColumnCount() {
        return 7;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
       switch (columnIndex) {
           case 0: return list.get(rowIndex).getId_barang();
           case 1: return list.get(rowIndex).getNama_barang();
           case 2: return list.get(rowIndex).getJenis_barang();
           case 3: return list.get(rowIndex).getSatuan();
           case 4: return list.get(rowIndex).getHarga();
           case 5: return list.get(rowIndex).getStok();
           
           default: return null;
       }
    }
    
    public String getColumnName(int column) {
        switch (column) {
            case 0: return "Id barang";
            case 1: return "Nama barang";
            case 2: return "Jenis barang";
            case 3: return "Satuan";
            case 4: return "Harga barang";
            case 5: return "Jumlah Stok";
            
            default : return null;
        }
    }
}
