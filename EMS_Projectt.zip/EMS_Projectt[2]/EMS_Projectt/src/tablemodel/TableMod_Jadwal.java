/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablemodel;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import model.Model_Jadwal;

/**
 *
 * @author Apis
 */
public class TableMod_Jadwal extends AbstractTableModel {
     private List<Model_Jadwal> list = new ArrayList<>();
    
    
    public void tambahData (Model_Jadwal mojad) {
        list.add(mojad);
        fireTableRowsInserted(list.size() -1, list.size()-1 );
        JOptionPane.showMessageDialog(null, "Data berhasil disimpan");
    }
    
    public void perbaruiData (int row, Model_Jadwal mojad) {
        list.add(row, mojad);
        fireTableDataChanged();
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui");
    }
    
    public void hapusData (int index, Model_Jadwal mojad) {
        list.remove(index);
        fireTableRowsDeleted(index, index);
        JOptionPane.showMessageDialog(null, "Data berhasil di hapus");
    }
    
    public void clear() {
        list.clear();
        fireTableDataChanged();
    }
    
    public void setData (List<Model_Jadwal> list) {
        clear();
        this.list.addAll(list);
        fireTableDataChanged();
    }
    
    public void setData (int index, Model_Jadwal mojad){
        list.set(index, mojad);
        fireTableRowsUpdated(index, index);
    }
    
    public Model_Jadwal getData (int index) {
        return list.get(index);
    }
    
    @Override
    public int getRowCount() {
        return list.size();
    }
    
    private final String[] columnNames = {"no","idNo","Tanggal","Nama Customer","Nama Teknisi","Alamat Customer","Keterangan"};

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        if (columnIndex == 0 ) {
            return "   " +  (rowIndex + 1);
        } else {
       switch (columnIndex -1 ) {
           case 0: return list.get(rowIndex).getNo();
           case 1: return list.get(rowIndex).getTanggal();
           case 2: return list.get(rowIndex).getCustomer();
           case 3: return list.get(rowIndex).getTeknisi();
           case 4: return list.get(rowIndex).getAlamat();
           case 5: return list.get(rowIndex).getKeterangan();
           
           default: return null;
            }
       }
    }
    
    public String getColumnName(int column) {
        if (column == 0) {
            return "   " + columnNames[column];
        } else {
            return columnNames[column];
        }
    }
}
