/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablemodel;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import model.Model_User;

/**
 *
 * @author Apis
 */
public class TableMod_User extends AbstractTableModel {
    private List<Model_User> list = new ArrayList<>();
    
    
    public void tambahData (Model_User mod_pengguna) {
        list.add(mod_pengguna);
        fireTableRowsInserted(list.size() -1, list.size()-1 );
        JOptionPane.showMessageDialog(null, "Data berhasil disimpan");
    }
    
    public void perbaruiData (int row, Model_User mod_pengguna) {
        list.add(row, mod_pengguna);
        fireTableDataChanged();
        JOptionPane.showMessageDialog(null, "Data berhasil diperbarui");
    }
    
    public void hapusData (int index, Model_User mod_pengguna) {
        list.remove(index);
        fireTableRowsDeleted(index, index);
        JOptionPane.showMessageDialog(null, "Data berhasil di hapus");
    }
    
    public void clear() {
        list.clear();
        fireTableDataChanged();
    }
    
    public void setData (List<Model_User> list) {
        clear();
        this.list.addAll(list);
        fireTableDataChanged();
    }
    
    public void setData (int index, Model_User mod_pengguna){
        list.set(index, mod_pengguna);
        fireTableRowsUpdated(index, index);
    }
    
    public Model_User getData (int index) {
        return list.get(index);
    }
    
    @Override
    public int getRowCount() {
        return list.size();
    }

    @Override
    public int getColumnCount() {
        return 6;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
       switch (columnIndex) {
           case 0: return list.get(rowIndex).getId_user();
           case 1: return list.get(rowIndex).getNama_pengguna();
           case 2: return list.get(rowIndex).getUsername();
           case 3: return list.get(rowIndex).getAlamat_user();
           case 4: return list.get(rowIndex).getTelp_user();
           case 5: return list.get(rowIndex).getLevel();
           
           default: return null;
       }
    }
    
    public String getColumnName(int column) {
        switch (column) {
            case 0: return "Id Pengguna";
            case 1: return "Nama";
            case 2: return "Username";
            case 3: return "Alamat";
            case 4: return "Telp";
            case 5: return "Level";
           
            
            default : return null;
        }
    }
}
