/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import config.koneksi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;
import javax.swing.JOptionPane;
import model.Model_Pekerjaan;
import service.Service_Pekerjaan;
/**
 *
 * @author Apis
 */
public class DAO_Pekerjaan implements Service_Pekerjaan{
    private Connection conn;
    
    public DAO_Pekerjaan (){
        conn = koneksi.getConnection();
    }
    
    @Override 
    public void tambahData(Model_Pekerjaan mojaan){
        PreparedStatement st = null;
        String sql = "INSERT INTO datapekerjaan (idno, tanggal , customer, alamat, hitungan, job, poin, teknisi, upah, keterangan) VALUES (?,?,?,?,?,?,?,?,?,?)";
        try {
            st = conn.prepareStatement(sql);
            
            
            st.setString(1, mojaan.getIdno());
            java.util.Date utilDate = mojaan.getTanggal();
            if (utilDate != null) {
                java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
                st.setDate(2, sqlDate);
            } else {
                st.setDate(2, null); // Handle null date appropriately
            }
            st.setString(3, mojaan.getCustomer());
            st.setString(4, mojaan.getAlamat());
            st.setLong(5, mojaan.getHitungan());
            st.setString(6, mojaan.getJob());
            st.setInt(7, mojaan.getPoin());
            st.setString(8, mojaan.getTeknisi());
            st.setInt(9, mojaan.getUpah());
            st.setString(10, mojaan.getKeterangan());
            
            st.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Pekerjaan.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Pekerjaan.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public void perbaruiData(Model_Pekerjaan mojaan) {
         PreparedStatement st = null;
        String sql = "UPDATE datapekerjaan SET tanggal=? , customer=?, alamat=?, hitungan=?, job=?, poin=?, teknisi=?, upah=?, keterangan=?  WHERE no='" + mojaan.getIdno() + "'";
        try {
            st = conn.prepareStatement(sql);
            
            java.util.Date utilDate = mojaan.getTanggal();
            if (utilDate != null) {
                java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
                st.setDate(1, sqlDate);
            } else {
                st.setDate(1, null); // Handle null date appropriately
            }
            st.setString(2, mojaan.getCustomer());
            st.setString(3, mojaan.getAlamat());
            st.setLong(4, mojaan.getHitungan());
            st.setString(5, mojaan.getJob());
            st.setInt(6, mojaan.getPoin());
            st.setString(7, mojaan.getTeknisi());
            st.setInt(8, mojaan.getUpah());
            st.setString(9, mojaan.getKeterangan());
            
            st.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Perbarui data gagal");
            Logger.getLogger(DAO_Pekerjaan.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Pekerjaan.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public void hapusData(Model_Pekerjaan mojaan) {
        PreparedStatement st = null;
        String sql = "DELETE FROM datapekerjaan WHERE idno=?";
        try {
            st = conn.prepareStatement(sql);
            
            st.setString(1, mojaan.getIdno());
            
            st.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Pekerjaan.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Pekerjaan.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }


    @Override
    public List<Model_Pekerjaan> getData() {
        PreparedStatement st = null;
        List list = new ArrayList();
        ResultSet rs = null;
        String sql = "SELECT jaan.idno, jaan.tanggal , jaan.customer , jaan.alamat, jaan.hitungan, jaan.job, jaan.poin, jaan.teknisi, jaan.upah, jaan.keterangan FROM datapekerjaan jaan";
        try {
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            while(rs.next()) {
                Model_Pekerjaan mojaan = new Model_Pekerjaan();
                
                mojaan.setIdno(rs.getString("idno"));
                mojaan.setTanggal(rs.getDate("tanggal"));
                mojaan.setCustomer(rs.getString("customer"));
                mojaan.setAlamat(rs.getString("alamat"));
                mojaan.setHitungan(rs.getLong("hitungan"));
                mojaan.setJob(rs.getString("job"));
                mojaan.setPoin(rs.getInt("poin"));
                mojaan.setTeknisi(rs.getString("teknisi"));
                mojaan.setUpah(rs.getInt("upah"));
                mojaan.setKeterangan(rs.getString("keterangan"));
                
                list.add(mojaan);                        
            }
            return list;
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(DAO_Pekerjaan.class.getName()).log(Level.SEVERE, null , ex);
            return null;
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_Pekerjaan.class.getName()).log(Level.SEVERE, null , ex);
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_Pekerjaan.class.getName()).log(Level.SEVERE, null , ex);
                }
            }
        }
    }

    @Override
    public List<Model_Pekerjaan> pencarian(String id) {
        PreparedStatement st = null;
        List list = new ArrayList();
        ResultSet rs = null;
        String sql = "SELECT jaan.idno, jaan.tanggal , jaan.customer , jaan.alamat, jaan.hitungan, jaan.job, jaan.poin, jaan.teknisi, jaan.upah, jaan.keterangan FROM datapekerjaan jaan";
        try {
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            while (rs.next()) {
                Model_Pekerjaan mojaan = new Model_Pekerjaan();
                
                mojaan.setIdno(rs.getString("idno"));
               java.util.Date utilDate = mojaan.getTanggal();
            if (utilDate != null) {
                java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
                st.setDate(1, sqlDate);
            } else {
                st.setDate(1, null); // Handle null date appropriately
            }
                mojaan.setCustomer(rs.getString("customer"));
                mojaan.setAlamat(rs.getString("alamat"));
                mojaan.setHitungan(rs.getLong("hitungan"));
                mojaan.setJob(rs.getString("job"));
                mojaan.setPoin(rs.getInt("poin"));
                mojaan.setTeknisi(rs.getString("teknisi"));
                mojaan.setUpah(rs.getInt("upah"));
                mojaan.setKeterangan(rs.getString("keterangan"));
                
                list.add(mojaan);                        
            }
            return list;
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(DAO_Pekerjaan.class.getName()).log(Level.SEVERE, null , ex);
            return null;
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Pekerjaan.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
            if (rs!=null) {
                try {
                    rs.close();
                } catch (SQLException ex){
                    Logger.getLogger(DAO_Pekerjaan.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public List<Model_Pekerjaan> pencarian2(String id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    @Override
    public String nomor() {
       PreparedStatement st = null;
        ResultSet rs = null;
        String urutan = "001";
        
        Date now = new Date();
        
        
        SimpleDateFormat  noFormat = new SimpleDateFormat("yyMM");
        
        String sql = "SELECT no FROM jadwal ORDER BY no DESC LIMIT 1";
        String noPrefix = noFormat.format(now);
        
       try  {
           st = conn.prepareStatement(sql);
            rs = st.executeQuery();
           if (rs.next()) {
                String lastNo = rs.getString("no");
                if (lastNo != null && lastNo.startsWith(noPrefix)) {
                    // Extract numeric part from the last number and increment it
                    String numericPart = lastNo.substring(noPrefix.length());
                    int nextNumber = Integer.parseInt(numericPart) + 1;
                    urutan = String.format("%03d", nextNumber);  // Format to 3 digits with leading zeros
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st != null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE , null , ex);
                }
            }
        }
        return noPrefix + urutan;
    }

    @Override
    public List<Model_Pekerjaan> ambilData() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Model_Pekerjaan> ambilData2() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    @Override
    public Model_Pekerjaan getById(String id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Model_Pekerjaan getDataById(String Id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
}
