/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import config.koneksi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Model_Jadwal;
import service.Service_Jadwal;

/**
 *
 * @author Apis
 */
public class DAO_Jadwal implements Service_Jadwal {
    private Connection conn;
    
    public DAO_Jadwal (){
        conn = koneksi.getConnection();
    }
    
    @Override 
    public void tambahData(Model_Jadwal mojad){
        PreparedStatement st = null;
        String sql = "INSERT INTO jadwal (no, tanggal, customer, teknisi, alamat, keterangan) VALUES (?,?,?,?,?,?)";
        try {
            st = conn.prepareStatement(sql);
            
            st.setString(1, mojad.getNo());
           java.util.Date utilDate = mojad.getTanggal();
            if (utilDate != null) {
                java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
                st.setDate(2, sqlDate);
            } else {
                st.setDate(2, null); // Handle null date appropriately
            }
            st.setString(3, mojad.getCustomer());
            st.setString(4, mojad.getTeknisi());
            st.setString(5, mojad.getAlamat());
            st.setString(6, mojad.getKeterangan());
            
            st.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Jadwal.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Jadwal.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public void perbaruiData(Model_Jadwal mojad) {
         PreparedStatement st = null;
        String sql = "UPDATE jadwal SET tanggal=? , customer=?, teknisi=?, alamat=?, keterangan=?  WHERE no='" + mojad.getNo() + "'";
        try {
            st = conn.prepareStatement(sql);
            
            
           java.util.Date utilDate = mojad.getTanggal();
            if (utilDate != null) {
                java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
                st.setDate(1, sqlDate);
            } else {
                st.setDate(1, null); // Handle null date appropriately
            }
            st.setString(2, mojad.getCustomer());
            st.setString(3, mojad.getTeknisi());
            st.setString(4, mojad.getAlamat());
            st.setString(5, mojad.getKeterangan());
            
            st.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Perbarui data gagal");
            Logger.getLogger(DAO_Jadwal.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Jadwal.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public void hapusData(Model_Jadwal mojad) {
        PreparedStatement st = null;
        String sql = "DELETE FROM jadwal WHERE no=?";
        try {
            st = conn.prepareStatement(sql);
            
            st.setString(1, mojad.getNo());
            
            st.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public Model_Jadwal getById(String id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    

    @Override
    public List<Model_Jadwal> getData() {
        PreparedStatement st = null;
        
        List list = new ArrayList();
        ResultSet rs = null;
        String sql = "SELECT jad.no , jad.tanggal , jad.customer , jad.teknisi, jad.alamat , jad.keterangan FROM jadwal jad";
        try {
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            while(rs.next()) {
                Model_Jadwal mojad = new Model_Jadwal();
                
                mojad.setNo(rs.getString("no"));
                mojad.setTanggal(rs.getDate("tanggal"));
                mojad.setCustomer(rs.getString("customer"));
                mojad.setTeknisi(rs.getString("teknisi"));
                mojad.setAlamat(rs.getString("alamat"));
                mojad.setKeterangan(rs.getString("keterangan"));
                
                list.add(mojad);                        
            }
            return list;
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null , ex);
            return null;
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null , ex);
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null , ex);
                }
            }
        }
    }

    @Override
    public List<Model_Jadwal> pencarian(String id) {
        PreparedStatement st = null;
        List list = new ArrayList();
        ResultSet rs = null;
        String sql = "SELECT jad.tanggal, " +
                "jad.nama, jad.project, jad.km, jad.total, jad.keterangan FROM jadwal jad" ;
        try {
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            while (rs.next()) {
                Model_Jadwal mojad = new Model_Jadwal();
                
                mojad.setNo(rs.getString("no"));
                mojad.setTanggal(rs.getDate("tanggal"));
                mojad.setCustomer(rs.getString("customer"));
                mojad.setTeknisi(rs.getString("teknisi"));
                mojad.setAlamat(rs.getString("alamat"));
                mojad.setKeterangan(rs.getString("keterangan"));
                 
            }
            return list;
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null , ex);
            return null;
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
            if (rs!=null) {
                try {
                    rs.close();
                } catch (SQLException ex){
                    Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public List<Model_Jadwal> pencarian2(String id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    @Override
    public String nomor() {
        PreparedStatement st = null;
        ResultSet rs = null;
        String urutan = "001";
        
        Date now = new Date();
        
        
        SimpleDateFormat  noFormat = new SimpleDateFormat("yyMM");
        
        String sql = "SELECT no FROM jadwal ORDER BY no DESC LIMIT 1";
        String noPrefix = noFormat.format(now);
        
       try  {
           st = conn.prepareStatement(sql);
            rs = st.executeQuery();
           if (rs.next()) {
                String lastNo = rs.getString("no");
                if (lastNo != null && lastNo.startsWith(noPrefix)) {
                    // Extract numeric part from the last number and increment it
                    String numericPart = lastNo.substring(noPrefix.length());
                    int nextNumber = Integer.parseInt(numericPart) + 1;
                    urutan = String.format("%03d", nextNumber);  // Format to 3 digits with leading zeros
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st != null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE , null , ex);
                }
            }
        }
        return noPrefix + urutan;
    }

    @Override
    public List<Model_Jadwal> ambilData() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Model_Jadwal> ambilData2() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Model_Jadwal getDataByID(String Id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
