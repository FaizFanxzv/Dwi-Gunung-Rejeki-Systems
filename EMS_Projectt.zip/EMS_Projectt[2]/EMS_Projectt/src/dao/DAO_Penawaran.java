/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import config.koneksi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Model_Penawaran;
import service.Service_Penawaran;

/**
 *
 * @author Apis
 */
public class DAO_Penawaran implements Service_Penawaran {
     private Connection conn;
    
    public DAO_Penawaran (){
        conn = koneksi.getConnection();
    }
    
    @Override 
    public void tambahData(Model_Penawaran monaw){
        PreparedStatement st = null;
        String sql = "INSERT INTO datapenawaran (no, jumlah, satuan, tipe, keterangan, harga , total) VALUES (?,?,?,?,?,?,?)";
        try {
            st = conn.prepareStatement(sql);
            
            st.setString(1, monaw.getNo()); 
            st.setInt(2, monaw.getJumlah());
            st.setString(3, monaw.getSatuan());
            st.setString(4, monaw.getTipe());
            st.setString(5, monaw.getKeterangan());
            st.setLong(6, monaw.getHarga());
            st.setLong(7, monaw.getTotal());
            
            st.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public void perbaruiData(Model_Penawaran monaw) {
         PreparedStatement st = null;
        String sql = "UPDATE datapenawaran SET jumlah=? , satuan=?, tipe=?, keterangan=?, harga=?, total=?  WHERE no='" + monaw.getNo() + "'";
        try {
            st = conn.prepareStatement(sql);
            
            st.setString(1, monaw.getNo());
            st.setInt(2, monaw.getJumlah());
            st.setString(3, monaw.getSatuan());
            st.setString(4, monaw.getTipe());
            st.setString(5, monaw.getKeterangan());
            st.setLong(6, monaw.getHarga());
            st.setLong(7, monaw.getTotal());
            
            st.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Perbarui data gagal");
            Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public void hapusData(Model_Penawaran monaw) {
        PreparedStatement st = null;
        String sql = "DELETE FROM datapenawaran WHERE no=?";
        try {
            st = conn.prepareStatement(sql);
            
            st.setString(1, monaw.getNo());
            
            st.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public Model_Penawaran getById(String id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   

    @Override
    public List<Model_Penawaran> getData() {
        PreparedStatement st = null;
        
        List list = new ArrayList();
        ResultSet rs = null;
        String sql = "SELECT naw.no , naw.jumlah , naw.satuan , naw.tipe, naw.keterangan, naw.harga, naw.total FROM datapenawaran naw";
        try {
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            while(rs.next()) {
                Model_Penawaran monaw = new Model_Penawaran();
                
                monaw.setNo(rs.getString("no"));
                monaw.setJumlah(rs.getInt("jumlah"));
                monaw.setSatuan(rs.getString("satuan"));
                monaw.setTipe(rs.getString("tipe"));
                monaw.setKeterangan(rs.getString("keterangan"));
                monaw.setHarga(rs.getLong("harga"));
                monaw.setTotal(rs.getLong("total"));
                
                list.add(monaw);                        
            }
            return list;
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null , ex);
            return null;
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null , ex);
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null , ex);
                }
            }
        }
    }

    @Override
    public List<Model_Penawaran> pencarian(String id) {
        PreparedStatement st = null;
        List list = new ArrayList();
        ResultSet rs = null;
        String sql = "SELECT naw.no , naw.jumlah , naw.satuan , naw.tipe, naw.keterangan, naw.harga, naw.total FROM datapenawaran naw";
        try {
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            while (rs.next()) {
                Model_Penawaran monaw = new Model_Penawaran();
                
                monaw.setNo(rs.getString("no"));
                monaw.setJumlah(rs.getInt("jumlah"));
                monaw.setSatuan(rs.getString("satuan"));
                monaw.setTipe(rs.getString("tipe"));
                monaw.setKeterangan(rs.getString("keterangan"));
                monaw.setHarga(rs.getLong("harga"));
                monaw.setTotal(rs.getLong("total"));
            }
            return list;
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null , ex);
            return null;
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
            if (rs!=null) {
                try {
                    rs.close();
                } catch (SQLException ex){
                    Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public List<Model_Penawaran> pencarian2(String id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    @Override
    public String nomor() {
        PreparedStatement st = null;
        ResultSet rs = null;
        String urutan = "001";
        
        Date now = new Date();
        
        
        SimpleDateFormat  noFormat = new SimpleDateFormat("yyMM");
        
        String sql = "SELECT no FROM jadwal ORDER BY no DESC LIMIT 1";
        String noPrefix = noFormat.format(now);
        
       try  {
           st = conn.prepareStatement(sql);
            rs = st.executeQuery();
           if (rs.next()) {
                String lastNo = rs.getString("no");
                if (lastNo != null && lastNo.startsWith(noPrefix)) {
                    // Extract numeric part from the last number and increment it
                    String numericPart = lastNo.substring(noPrefix.length());
                    int nextNumber = Integer.parseInt(numericPart) + 1;
                    urutan = String.format("%03d", nextNumber);  // Format to 3 digits with leading zeros
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st != null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE , null , ex);
                }
            }
        }
        return noPrefix + urutan;
    }
    
    @Override
    public Model_Penawaran getDataByID(String Id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Model_Penawaran> ambilData() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Model_Penawaran> ambilData2() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
