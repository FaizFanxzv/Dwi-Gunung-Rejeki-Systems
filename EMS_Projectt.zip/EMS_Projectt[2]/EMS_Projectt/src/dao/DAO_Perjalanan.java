/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import config.koneksi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;
import javax.swing.JOptionPane;
import model.Model_Perjalanan;
import service.Service_Perjalanan;

public class DAO_Perjalanan implements Service_Perjalanan {
    
    private Connection conn;
    
    public DAO_Perjalanan (){
        conn = koneksi.getConnection();
    }
    
    @Override 
    public void tambahData(Model_Perjalanan mojal){
        PreparedStatement st = null;
        String sql = "INSERT INTO dataperjalanan (no, tanggal, nama, project, KM, total, keterangan) VALUES (?,?,?,?,?,?,?)";
        try {
            st = conn.prepareStatement(sql);
            
            st.setString(1, mojal.getNo());
            java.util.Date utilDate = mojal.getTanggal();
            if (utilDate != null) {
                java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
                st.setDate(2, sqlDate);
            } else {
                st.setDate(2, null); // Handle null date appropriately
            }
            st.setString(3, mojal.getNama());
            st.setString(4, mojal.getProject());
            st.setInt(5, mojal.getKM());
            st.setLong(6, mojal.getTotal());
            st.setString(7, mojal.getKeterangan());
            
            st.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public void perbaruiData(Model_Perjalanan mojal) {
         PreparedStatement st = null;
        String sql = "UPDATE dataperjalanan SET tanggal=? , nama=?, project=?, KM=?, total=?, keterangan=?  WHERE no='" + mojal.getNo() + "'";
        try {
            st = conn.prepareStatement(sql);
            
            java.util.Date utilDate = mojal.getTanggal();
            if (utilDate != null) {
                java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
                st.setDate(1, sqlDate);
            } else {
                st.setDate(1, null); // Handle null date appropriately
            }
            st.setString(2, mojal.getNama());
            st.setString(3, mojal.getProject());
            st.setInt(4, mojal.getKM());
            st.setLong(5, mojal.getTotal());
            st.setString(6, mojal.getKeterangan());
            
            st.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Perbarui data gagal");
            Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public void hapusData(Model_Perjalanan mojal) {
        PreparedStatement st = null;
        String sql = "DELETE FROM dataperjalanan WHERE no=?";
        try {
            st = conn.prepareStatement(sql);
            
            st.setString(1, mojal.getNo());
            
            st.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public Model_Perjalanan getById(String id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Model_Perjalanan> getDataByID() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Model_Perjalanan> getData() {
        PreparedStatement st = null;
        
        List list = new ArrayList();
        ResultSet rs = null;
        String sql = "SELECT jln.no , jln.tanggal , jln.nama , jln.project, jln.km, jln.total, jln.keterangan FROM dataperjalanan jln";
        try {
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            while(rs.next()) {
                Model_Perjalanan mojal = new Model_Perjalanan();
                
                mojal.setNo(rs.getString("no"));
                mojal.setTanggal(rs.getDate("tanggal"));
                mojal.setNama(rs.getString("nama"));
                mojal.setProject(rs.getString("project"));
                mojal.setKM(rs.getInt("KM"));
                mojal.setTotal(rs.getLong("total"));
                mojal.setKeterangan(rs.getString("keterangan"));
                
                list.add(mojal);                        
            }
            return list;
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null , ex);
            return null;
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null , ex);
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null , ex);
                }
            }
        }
    }

    @Override
    public List<Model_Perjalanan> pencarian(String id) {
        PreparedStatement st = null;
        List list = new ArrayList();
        ResultSet rs = null;
        String sql = "SELECT jln.no, jln.tanggal, " +
                "jln.nama, jln.project, jln.km, jln.total, jln.keterangan FROM dataperjalanan jln" ;
        try {
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            while (rs.next()) {
                Model_Perjalanan mojal = new Model_Perjalanan();
                mojal.setNo(rs.getString("no"));
                mojal.setTanggal(rs.getDate("tanggal"));
                mojal.setNama(rs.getString("nama"));
                mojal.setProject(rs.getString("project"));
                mojal.setKM(rs.getInt("KM"));
                mojal.setTotal(rs.getLong("total"));
                mojal.setKeterangan(rs.getString("keterangan"));
            }
            return list;
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null , ex);
            return null;
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
            if (rs!=null) {
                try {
                    rs.close();
                } catch (SQLException ex){
                    Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public List<Model_Perjalanan> pencarian2(String id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
   @Override
    public String nomor() {
        PreparedStatement st = null;
        ResultSet rs = null;
        String urutan = "001";
        
        Date now = new Date();
        
        
        SimpleDateFormat  noFormat = new SimpleDateFormat("yyMM");
        
        String sql = "SELECT no FROM dataperjalanan ORDER BY no DESC LIMIT 1";
        String noPrefix = noFormat.format(now);
        
       try  {
           st = conn.prepareStatement(sql);
            rs = st.executeQuery();
           if (rs.next()) {
                String lastNo = rs.getString("no");
                if (lastNo != null && lastNo.startsWith(noPrefix)) {
                    // Extract numeric part from the last number and increment it
                    String numericPart = lastNo.substring(noPrefix.length());
                    int nextNumber = Integer.parseInt(numericPart) + 1;
                    urutan = String.format("%03d", nextNumber);  // Format to 3 digits with leading zeros
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st != null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_Perjalanan.class.getName()).log(Level.SEVERE , null , ex);
                }
            }
        }
        return noPrefix + urutan;
    }
}
