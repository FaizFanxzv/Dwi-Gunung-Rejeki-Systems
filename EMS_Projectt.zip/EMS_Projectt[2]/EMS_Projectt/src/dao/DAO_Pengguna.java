/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import config.koneksi;
import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import model.Model_User;
import service.Service_Pengguna;

/**
 *
 * @author Apis
 */
public class DAO_Pengguna implements Service_Pengguna{
    private Connection conn;
    
    public DAO_Pengguna (){
        conn = koneksi.getConnection();
    }
    
    @Override 
    public void tambahData(Model_User mod_pengguna){
        PreparedStatement st = null;
        String sql = "INSERT INTO pengguna (id_user, nama_pengguna, username, password, alamat_user, telp_user, level, gambar) VALUES (?,?,?,?,?,?,?,?)";
        try {
            st = conn.prepareStatement(sql);
            
            st.setString(1, mod_pengguna.getId_user());
            st.setString(2, mod_pengguna.getNama_pengguna());
            st.setString(3, mod_pengguna.getUsername());
            st.setString(4, Encrypt.getmd5java(mod_pengguna.getPassword()));
            st.setString(5, mod_pengguna.getAlamat_user());
            st.setString(6, mod_pengguna.getTelp_user());
            st.setString(7, mod_pengguna.getLevel());
            
            // Mengubah gambar menjadi bytes array
            String imagePath = mod_pengguna.getImagePath();
            if (imagePath != null) {
            File imageFile = new File(imagePath);
            FileInputStream fis = new FileInputStream(imageFile);
            byte[] imageData = new byte [ (int) imageFile.length()];
            fis.read(imageData);
            fis.close();
            st.setBytes(8, imageData);
        } else {
                st.setNull(8, java.sql.Types.BLOB);
            }
            
            st.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Pengguna.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(DAO_Pengguna.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(DAO_Pengguna.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Pengguna.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public void perbaruiData(Model_User mod_pengguna) {
         PreparedStatement st = null;
        String sql = "UPDATE pengguna SET nama_pengguna=? , username=?, alamat_user=?, telp_user=?, level=?";
                     if (mod_pengguna.getImagePath() != null && !mod_pengguna.getImagePath().isEmpty())
                     {
                         sql += ",gambar=?";
                     }
                        sql += " WHERE id_user=?";
        try {
            st = conn.prepareStatement(sql);
            
            st.setString(1, mod_pengguna.getNama_pengguna());
            st.setString(2, mod_pengguna.getUsername());
           // st.setString(3, Encrypt.getmd5java(mod_pengguna.getPassword()));
            st.setString(3, mod_pengguna.getAlamat_user());
            st.setString(4, mod_pengguna.getTelp_user());
            st.setString(5, mod_pengguna.getLevel());
            
            if (mod_pengguna.getImagePath() != null && !mod_pengguna.getImagePath().isEmpty()){
                File imageFile = new File (mod_pengguna.getImagePath());
                FileInputStream fis = new FileInputStream(imageFile);
                st.setBinaryStream(6, fis, (int) imageFile.length());
                st.setString(7, mod_pengguna.getId_user());
            } else {
                st.setString(6, mod_pengguna.getId_user());
            }
            
            st.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Perbarui data gagal");
            Logger.getLogger(DAO_Pengguna.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(DAO_Pengguna.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Pengguna.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public void hapusData(Model_User mod_pengguna) {
        PreparedStatement st = null;
        String sql = "DELETE FROM pengguna WHERE id_user  =?";
        try {
            st = conn.prepareStatement(sql);
            
            st.setString(1, mod_pengguna.getId_user());
            
            st.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Pengguna.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Pengguna.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public Model_User getById(String id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   

    @Override
    public List<Model_User> getData() {
        PreparedStatement st = null;       
        List list = new ArrayList();
        ResultSet rs = null;
        String sql = "SELECT * FROM pengguna";
        try {
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            while(rs.next()) {
                Model_User mod_pengguna = new Model_User();
                
                mod_pengguna.setId_user(rs.getString("id_user"));
                mod_pengguna.setNama_pengguna(rs.getString("nama_pengguna"));
                mod_pengguna.setUsername(rs.getString("username"));
                mod_pengguna.setAlamat_user(rs.getString("alamat_user"));
                mod_pengguna.setTelp_user(rs.getString("telp_user"));
                mod_pengguna.setLevel(rs.getString("level"));
  
                list.add(mod_pengguna);                        
            }
            return list;
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(DAO_Pengguna.class.getName()).log(Level.SEVERE, null , ex);
            return null;
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_Pengguna.class.getName()).log(Level.SEVERE, null , ex);
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_Pengguna.class.getName()).log(Level.SEVERE, null , ex);
                }
            }
        }
    }

    @Override
    public List<Model_User> pencarian(String id) {
        PreparedStatement st = null;
        List list = new ArrayList();
        ResultSet rs = null;
        String sql = "SELECT * FROM pengguna WHERE id_user LIKE '&"+id+"&' OR  username LIKE '&"+id+"&' OR telp_user LIKE '&"+id+"&'" ;
        try {
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            while(rs.next()) {
                Model_User mod_pengguna = new Model_User();
                
                mod_pengguna.setId_user(rs.getString("id_user"));
                mod_pengguna.setNama_pengguna(rs.getString("nama_pengguna"));
                mod_pengguna.setUsername(rs.getString("username"));
                mod_pengguna.setAlamat_user(rs.getString("telp_user"));
                mod_pengguna.setTelp_user(rs.getString("alamat_user"));
                mod_pengguna.setLevel(rs.getString("level"));
            }
            return list;
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(DAO_Pengguna.class.getName()).log(Level.SEVERE, null , ex);
            return null;
        } finally {
            if (st!=null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_Pengguna.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
            if (rs!=null) {
                try {
                    rs.close();
                } catch (SQLException ex){
                    Logger.getLogger(DAO_Pengguna.class.getName()).log(Level.SEVERE, null ,ex);
                }
            }
        }
    }

    @Override
    public void tampilGambar(JLabel lb_gambar, String id) {
        try {
            String sql = "SELECT * FROM pengguna WHERE id_user = '" + id + "'";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            if (rs.next()) {
                byte[] img = rs.getBytes("gambar");
                if (img != null ) {
                    ImageIcon imageIcon = new ImageIcon(new ImageIcon (img).getImage().getScaledInstance(lb_gambar.getWidth(), lb_gambar.getHeight(), 0));
                    lb_gambar.setIcon(imageIcon);
                } else {
                    ImageIcon defaultIcon = new ImageIcon(getClass().getResource("/img/icons8_worker_100px.png"));
                    lb_gambar.setIcon(defaultIcon);
                }
            } 
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
}
    
    
  

